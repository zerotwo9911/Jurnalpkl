# Checklist Deployment

- [ ] Repository GitHub sudah dibuat.
- [ ] Semua file project sudah di-upload.
- [ ] `.env` tidak di-upload.
- [ ] PostgreSQL sudah dibuat.
- [ ] `DATABASE_URL` tersedia di Vercel.
- [ ] `AUTH_SECRET` tersedia di Vercel dan minimal 32 karakter.
- [ ] Build command menggunakan `npm run build`.
- [ ] Migration `prisma/migrations/0001_init` ikut di repository.
- [ ] `npm run build` tidak menjalankan seed database.
- [ ] Jika seed demo diperlukan, jalankan manual dengan `SEED_PASSWORD`.
- [ ] Setelah deploy, buka URL Vercel dan uji login.
